This data goes with the tutorial available at the Gitools documentation: http://www.gitools.org/documentation
